CREATE DATABASE urna;
USE urna;

CREATE TABLE IF NOT EXISTS funcionario (
id_funcionario INT(11) NOT NULL,
nome VARCHAR(50) NOT NULL,
login VARCHAR(50) NOT NULL,
senha VARCHAR(15) NOT NULL,
status_titulo SMALLINT DEFAULT (1)
);

CREATE TABLE IF NOT EXISTS eleitor (
id_eleitor INT(11) NOT NULL,
nome VARCHAR(50) NOT NULL,
cpf VARCHAR(15) NOT NULL,
num_titulo VARCHAR(12) NOT NULL,
status_titulo SMALLINT DEFAULT (1)
);

CREATE TABLE IF NOT EXISTS candidato (
id_candidato INT(11) NOT NULL,
nome VARCHAR(50) NOT NULL,
partido VARCHAR(50) NOT NULL,
numero INT(11) NOT NULL,
cargo INT NOT NULL
-- imagem BLOB NOT NULL
);

CREATE TABLE IF NOT EXISTS eleitor_candidato (
id_eleitor_candidato INT(11) NOT NULL,
funcionario INT NOT NULL,
eleitor INT NOT NULL,
candidato INT NOT NULL
);

CREATE TABLE IF NOT EXISTS cargo (
id_cargo INT(11) NOT NULL,
cargo VARCHAR(30) NOT NULL
);

ALTER TABLE funcionario
CHANGE COLUMN id_funcionario id_funcionario INT(11) NOT NULL AUTO_INCREMENT,
ADD PRIMARY KEY (id_funcionario);

ALTER TABLE eleitor
CHANGE COLUMN id_eleitor id_eleitor INT(11) NOT NULL AUTO_INCREMENT,
ADD PRIMARY KEY (id_eleitor);

ALTER TABLE candidato
CHANGE COLUMN id_candidato id_candidato INT(11) NOT NULL AUTO_INCREMENT,
ADD PRIMARY KEY (id_candidato);

ALTER TABLE eleitor_candidato
CHANGE COLUMN id_eleitor_candidato id_eleitor_candidato INT(11) NOT NULL AUTO_INCREMENT,
ADD PRIMARY KEY (id_eleitor_candidato);

ALTER TABLE cargo
CHANGE COLUMN id_cargo id_cargo INT(11) NOT NULL AUTO_INCREMENT,
ADD PRIMARY KEY (id_cargo);

ALTER TABLE candidato
ADD CONSTRAINT fk_candidato_cargo FOREIGN KEY (cargo) REFERENCES cargo (id_cargo);

ALTER TABLE eleitor_candidato
ADD CONSTRAINT fk_eleitor_candidato_funcionario FOREIGN KEY (funcionario) REFERENCES funcionario (id_funcionario),
ADD CONSTRAINT fk_eleitor_candidato_eleitor FOREIGN KEY (eleitor) REFERENCES eleitor (id_eleitor),
ADD CONSTRAINT fk_eleitor_candidato_candidato FOREIGN KEY (candidato) REFERENCES candidato (id_candidato);

DELIMITER $$ 
CREATE PROCEDURE PROC_CAD_CARGO -- como boa prática, nomeie a procedure e qual é o seu objetivo. Nesse exemplo é uma PROC (procedure) CAD (cadastro) CARGO (nome da tabela)
	(
		IN pro_cargo VARCHAR(30), -- aqui você deve atribuiur os campos de registro dos valores ao chamar a procedure, recomendo que coloque a mesma coisa que consta na tabela, colocando a informação de procedure na frente (proc_)
		OUT id INT -- como vai utilizar um insert, é bom que coloque o id como OUT, dessa maneira, conseguirá chamar o ultimo id registrado sem precisar inserir manualmente 
	)
BEGIN
	INSERT INTO cargo (cargo) VALUE (pro_cargo); -- aqui agora você vai dar o comando INSERT e preencher o básico mudando apenas os valores para os campos de registro criados
    SELECT LAST_INSERT_ID() INTO id; -- basta dar esse comando para ele fazer o chamado dos dados no ultimo id valido
END$$

DELIMITER $$ 
CREATE PROCEDURE PROC_CAD_ELEITOR 
	(
		IN pro_nome VARCHAR(50),
        IN pro_cpf VARCHAR(15),
        IN pro_num_titulo VARCHAR(12),
        IN pro_status_titulo SMALLINT,
        OUT id INT
	)
BEGIN
	INSERT INTO eleitor (nome, cpf, num_titulo, status_titulo) VALUES (pro_nome, pro_cpf, pro_num_titulo, pro_status_titulo);
    SELECT LAST_INSERT_ID() INTO id;
END$$

DELIMITER $$ 
CREATE PROCEDURE PROC_CAD_CANDIDATO 
	(
		IN pro_nome VARCHAR(50),
        IN pro_partido VARCHAR(50),
        IN pro_numero INT(11),
        IN pro_cargo INT,
        OUT id INT
	)
BEGIN
	INSERT INTO candidato (nome, partido, numero, cargo) VALUES (pro_nome, pro_partido, pro_numero, pro_cargo);
    SELECT LAST_INSERT_ID() INTO id;
END$$

DELIMITER $$ 
CREATE PROCEDURE PROC_CAD_ELEITOR_CANDIDATO
	(
		IN pro_funcionario INT,
        IN pro_eleitor INT,
        IN pro_candidato INT,
        OUT id INT
	)
BEGIN
	INSERT INTO eleitor_candidato (funcionario,eleitor,candidato) VALUE (pro_funcionario,pro_eleitor,pro_candidato);
    SELECT LAST_INSERT_ID() INTO id;
END$$

INSERT INTO funcionario (nome, login, senha) VALUES ('admin', 'admin', 'eleicao2022');
INSERT INTO funcionario (nome, login, senha) VALUES ('jose da silva', 'jose', '123');
INSERT INTO funcionario (nome, login, senha) VALUES ('maria dos santos', 'maria', '321');
INSERT INTO funcionario (nome, login, senha) VALUES ('joao de souza', 'joao', '555');

-- Cadastrar Cargos
CALL PROC_CAD_CARGO ('Presidente',@id);
CALL PROC_CAD_CARGO ('Governador',@id);
CALL PROC_CAD_CARGO ('Senador',@id);
CALL PROC_CAD_CARGO ('Deputado Federal',@id);
CALL PROC_CAD_CARGO ('Deputado Estadual',@id);

-- Cadastrar Eleitor
CALL PROC_CAD_ELEITOR ('Bruno','98653214700','1234','1',@id);
CALL PROC_CAD_ELEITOR ('Juarez','95637846129','4321','1',@id);
CALL PROC_CAD_ELEITOR ('Luis','18613549534','5678','1',@id);
CALL PROC_CAD_ELEITOR ('Victor','85632489623','8765','1',@id);
CALL PROC_CAD_ELEITOR ('João','99966633312','0000','0',@id);

-- Presidente
CALL PROC_CAD_CANDIDATO ('Branco/Nulo','Branco/Nulo','00','1',@id);
CALL PROC_CAD_CANDIDATO ('juscelino kubitschek ','Partido Social Democrático','55','1',@id);
CALL PROC_CAD_CANDIDATO ('Getúlio Vargas','Partido Trabalhista Brasileiro','99','1',@id);
CALL PROC_CAD_CANDIDATO ('José Sarney','Partido do Movimento Democrático Brasileiro','15','1',@id);
CALL PROC_CAD_CANDIDATO ('Fernando Henrique Cardoso','Partido da Social Democracia Brasileira','45','1',@id);
CALL PROC_CAD_CANDIDATO ('Luiz Inácio Lula da Silva','Partido dos Trabalhadores','13','1',@id);

-- Governador
CALL PROC_CAD_CANDIDATO ('Branco/Nulo','Branco/Nulo','00','2',@id);
CALL PROC_CAD_CANDIDATO ('Lucas Corleone','Partido Social Democrático','55','2',@id);
CALL PROC_CAD_CANDIDATO ('Ricardo Gecko','Partido Trabalhista Brasileiro','99','2',@id);
CALL PROC_CAD_CANDIDATO ('Josias Tarantino','Partido do Movimento Democrático Brasileiro','15','2',@id);
CALL PROC_CAD_CANDIDATO ('João Carpenter','Partido da Social Democracia Brasileira','45','2',@id);
CALL PROC_CAD_CANDIDATO ('Roberto Silva','Partido dos Trabalhadores','13','2',@id);

-- Senador
CALL PROC_CAD_CANDIDATO ('Branco/Nulo','Branco/Nulo','000','3',@id);
CALL PROC_CAD_CANDIDATO ('Raquel kubitschek ','Partido Social Democrático','555','3',@id);
CALL PROC_CAD_CANDIDATO ('Marta Vargas','Partido Trabalhista Brasileiro','999','3',@id);
CALL PROC_CAD_CANDIDATO ('Luciano Santos','Partido do Movimento Democrático Brasileiro','151','3',@id);
CALL PROC_CAD_CANDIDATO ('Henrique Neto','Partido da Social Democracia Brasileira','454','3',@id);
CALL PROC_CAD_CANDIDATO ('Fernando Souza','Partido dos Trabalhadores','133','3',@id);

-- Deputado Federal
CALL PROC_CAD_CANDIDATO ('Branco/Nulo','Branco/Nulo','0000','4',@id);
CALL PROC_CAD_CANDIDATO ('Felipe Pedrosa','Partido Social Democrático','5512','4',@id);
CALL PROC_CAD_CANDIDATO ('Pedro Sampaio','Partido Trabalhista Brasileiro','9912','4',@id);
CALL PROC_CAD_CANDIDATO ('Rafael Sodré','Partido do Movimento Democrático Brasileiro','1512','4',@id);
CALL PROC_CAD_CANDIDATO ('Juliana Cardoso','Partido da Social Democracia Brasileira','4512','4',@id);
CALL PROC_CAD_CANDIDATO ('Eduarda Campos','Partido dos Trabalhadores','1312','4',@id);

-- Deputado Estadual
CALL PROC_CAD_CANDIDATO ('Branco/Nulo','Branco/Nulo','00000','5',@id);
CALL PROC_CAD_CANDIDATO ('Maria Pereira ','Partido Social Democrático','55000','5',@id);
CALL PROC_CAD_CANDIDATO ('João Medeiros','Partido Trabalhista Brasileiro','99000','5',@id);
CALL PROC_CAD_CANDIDATO ('Alfredo Pedrosa','Partido do Movimento Democrático Brasileiro','15000','5',@id);
CALL PROC_CAD_CANDIDATO ('Pedro Moreira','Partido da Social Democracia Brasileira','45000','5',@id);
CALL PROC_CAD_CANDIDATO ('Luiza da Silva','Partido dos Trabalhadores','13000','5',@id);

/*
-- Armazenamento do voto (simulação)
CALL PROC_CAD_ELEITOR_CANDIDATO (1,1,1,@id);
CALL PROC_CAD_ELEITOR_CANDIDATO (1,2,1,@id);
CALL PROC_CAD_ELEITOR_CANDIDATO (1,3,2,@id);
CALL PROC_CAD_ELEITOR_CANDIDATO (2,4,2,@id);
CALL PROC_CAD_ELEITOR_CANDIDATO (1,5,1,@id);
*/


-- retorno geral dos votos
/*
select 
	can.nome as CANDIDATO,
    can.numero as NUMERO_ELEITORAL,
    can.partido as PARTIDO,
    car.cargo as CARGO
from eleitor_candidato  elecan
left join eleitor ele ON ele.id_eleitor = elecan.eleitor
left join candidato can ON can.id_candidato = elecan.candidato
left join cargo car ON car.id_cargo = can.cargo
where can.cargo = 1
*/


/*
-- EXEMPLO DE: retorno ordenado dos votos
CREATE VIEW apurar_votos AS
select 
	can.nome as CANDIDATO,
    can.numero as NUMERO_ELEITORAL,
    can.partido as PARTIDO,
    car.cargo as CARGO,
    count(can.nome) as QUANTIDADE_DE_VOTOS 
from eleitor_candidato  elecan
left join eleitor ele ON ele.id_eleitor = elecan.eleitor
left join candidato can ON can.id_candidato = elecan.candidato
left join cargo car ON car.id_cargo = can.cargo
where can.cargo = 1
group by can.nome
order by QUANTIDADE_DE_VOTOS desc
Limit 2;

-- select * from apurar_votos
*/




CREATE VIEW apurar_votos_presidentes AS
select 
	can.nome as CANDIDATO,
    can.numero as NUMERO_ELEITORAL,
    can.partido as PARTIDO,
    car.cargo as CARGO,
    count(can.nome) as VOTOS 
from eleitor_candidato  elecan
left join eleitor ele ON ele.id_eleitor = elecan.eleitor
left join candidato can ON can.id_candidato = elecan.candidato
left join cargo car ON car.id_cargo = can.cargo
where can.cargo = 1
group by can.nome
order by VOTOS desc;

CREATE VIEW apurar_votos_governadores AS
select 
	can.nome as CANDIDATO,
    can.numero as NUMERO_ELEITORAL,
    can.partido as PARTIDO,
    car.cargo as CARGO,
    count(can.nome) as VOTOS 
from eleitor_candidato  elecan
left join eleitor ele ON ele.id_eleitor = elecan.eleitor
left join candidato can ON can.id_candidato = elecan.candidato
left join cargo car ON car.id_cargo = can.cargo
where can.cargo = 2
group by can.nome
order by VOTOS desc;

CREATE VIEW apurar_votos_senadores AS
select 
	can.nome as CANDIDATO,
    can.numero as NUMERO_ELEITORAL,
    can.partido as PARTIDO,
    car.cargo as CARGO,
    count(can.nome) as VOTOS 
from eleitor_candidato  elecan
left join eleitor ele ON ele.id_eleitor = elecan.eleitor
left join candidato can ON can.id_candidato = elecan.candidato
left join cargo car ON car.id_cargo = can.cargo
where can.cargo = 3
group by can.nome
order by VOTOS desc;

CREATE VIEW apurar_votos_deputado_federal AS
select 
	can.nome as CANDIDATO,
    can.numero as NUMERO_ELEITORAL,
    can.partido as PARTIDO,
    car.cargo as CARGO,
    count(can.nome) as VOTOS 
from eleitor_candidato  elecan
left join eleitor ele ON ele.id_eleitor = elecan.eleitor
left join candidato can ON can.id_candidato = elecan.candidato
left join cargo car ON car.id_cargo = can.cargo
where can.cargo = 4
group by can.nome
order by VOTOS desc;

CREATE VIEW apurar_votos_deputado_estadual AS
select 
	can.nome as CANDIDATO,
    can.numero as NUMERO_ELEITORAL,
    can.partido as PARTIDO,
    car.cargo as CARGO,
    count(can.nome) as VOTOS 
from eleitor_candidato  elecan
left join eleitor ele ON ele.id_eleitor = elecan.eleitor
left join candidato can ON can.id_candidato = elecan.candidato
left join cargo car ON car.id_cargo = can.cargo
where can.cargo = 5
group by can.nome
order by VOTOS desc;