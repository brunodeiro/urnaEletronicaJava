package Connection.votos;

public class Votos {
    private int chaveFuncionario;
    private int chaveEleitor;
    private int chaveCandidato;

    public int getChaveFuncionario() {
        return chaveFuncionario;
    }

    public void setChaveFuncionario(int chaveFuncionario) {
        this.chaveFuncionario = chaveFuncionario;
    }

    public int getChaveEleitor() {
        return chaveEleitor;
    }

    public void setChaveEleitor(int chaveEleitor) {
        this.chaveEleitor = chaveEleitor;
    }

    public int getChaveCandidato() {
        return chaveCandidato;
    }

    public void setChaveCandidato(int chaveCandidato) {
        this.chaveCandidato = chaveCandidato;
    }    
    
    
    
}
