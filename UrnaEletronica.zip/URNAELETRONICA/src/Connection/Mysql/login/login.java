package Connection.Mysql.login;

import Connection.Mysql.ConnectionFactory;
import Connection.votos.Votos;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class login {
    public void buscarLogin(Votos v){
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement stmt = null;
        String sql = "CALL PROC_CAD_ELEITOR_CANDIDATO (?,?,?,@id)";
        try{
            stmt = con.prepareStatement(sql);
            stmt.setInt(1, v.getChaveFuncionario());
            stmt.setInt(2, v.getChaveEleitor());
            stmt.setInt(3, v.getChaveCandidato());
            
            stmt.executeUpdate();
            
        }catch(SQLException e){
            JOptionPane.showConfirmDialog(null,"Erro ao salvar os dados"+ e.toString());
        }finally{
            ConnectionFactory.closeConnection(con,stmt);
        }
    }
}
