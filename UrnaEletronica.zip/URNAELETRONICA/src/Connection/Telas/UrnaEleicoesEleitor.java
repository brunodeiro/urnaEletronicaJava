package Connection.Telas;

import Connection.Mysql.ConnectionFactory;
import Connection.Mysql.login.envioDeVoto;
import Connection.votos.Votos;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
/**
 *
 * @author bruno
 *
 * 
OBS:
- Passar os dados armazenados de uma tela para outra para possibilitar dar insert (pk_mes,pk_ele,pk_depEst,pk_depFed,pk_sen,pk_gov,pk_pres)
- incluir imagem
- dar insert ao clicar em branco 
- dar insert ao confirmar
*/

public class UrnaEleicoesEleitor extends javax.swing.JFrame {
    int funcionario;
    Votos voto = new Votos();
    envioDeVoto envio = new envioDeVoto();
    
    public void funToEle(Votos v){
        System.out.println("Funcionario: "+ v.getChaveFuncionario());
        this.funcionario = v.getChaveFuncionario();        
    }
    
    public UrnaEleicoesEleitor() {
        initComponents();       
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        ltitulo = new javax.swing.JLabel();
        titulo1 = new javax.swing.JTextField();
        btnApaga = new javax.swing.JButton();
        btnEntra = new javax.swing.JButton();
        btnSair1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(234, 242, 255));

        ltitulo.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        ltitulo.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        ltitulo.setText("Titulo:");
        ltitulo.setVerifyInputWhenFocusTarget(false);

        titulo1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        titulo1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        titulo1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                titulo1ActionPerformed(evt);
            }
        });

        btnApaga.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnApaga.setText("Apagar");
        btnApaga.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        btnApaga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnApagaActionPerformed(evt);
            }
        });

        btnEntra.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnEntra.setText("Entrar");
        btnEntra.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        btnEntra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEntraActionPerformed(evt);
            }
        });

        btnSair1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnSair1.setText("Sair");
        btnSair1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        btnSair1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSair1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(ltitulo, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(titulo1, javax.swing.GroupLayout.PREFERRED_SIZE, 211, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(68, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btnSair1, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnApaga, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnEntra, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(44, 44, 44))))
        );

        jPanel1Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnApaga, btnEntra, btnSair1});

        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(100, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(titulo1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ltitulo))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnApaga, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSair1, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnEntra, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(87, 87, 87))
        );

        jPanel1Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnApaga, btnEntra, btnSair1});

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(164, 164, 164)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(197, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(104, 104, 104)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(116, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void titulo1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_titulo1ActionPerformed
                
    }//GEN-LAST:event_titulo1ActionPerformed

    private void btnApagaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnApagaActionPerformed
        titulo1.setText("");        
    }//GEN-LAST:event_btnApagaActionPerformed

    private void btnEntraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEntraActionPerformed
             entrar();
    }//GEN-LAST:event_btnEntraActionPerformed

    private void btnSair1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSair1ActionPerformed
        // TODO add your handling code here:
        UrnaEleicoesConfiguracao configu = new UrnaEleicoesConfiguracao();
        configu.setVisible(true);
        dispose();
    }//GEN-LAST:event_btnSair1ActionPerformed

    private void entrar(){
        if(validaCamposObrigatorios()){
            JOptionPane.showMessageDialog(null, "Preencha todos os campos !");
        }else{
            Connection con = ConnectionFactory.getConnection();
            String titulo = titulo1.getText();
            try{       
                Statement stm = con.createStatement();
                String sql = "select * from eleitor where num_titulo = '"+titulo+"'";
                ResultSet rs = stm.executeQuery(sql);      

                if(rs.next()){
                    int pk_eleitor=rs.getInt(1);
                    voto.setChaveEleitor(pk_eleitor);
                    voto.setChaveFuncionario(funcionario);
                    System.out.println("Primary Key do eleitor é: "+ pk_eleitor);                
                    System.out.println("Teste GET funcionario: "+ funcionario); //passou !!
                    UrnaEleicoesDepEstadual depEst = new UrnaEleicoesDepEstadual();
                    depEst.eleToCan(voto);
                    depEst.setVisible(true);
                    dispose();                
                }else{
                    JOptionPane.showMessageDialog(null, "Dados incorretos !","Erro",JOptionPane.ERROR_MESSAGE);
                    titulo1.setText("");
                }    

            }catch(SQLException e){
                JOptionPane.showMessageDialog(null, "Erro nos dados: " + e.toString());
            }
        } 
    }
    
    private boolean validaCamposObrigatorios(){
        return (titulo1.getText().equals(""));
    }
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(UrnaEleicoesEleitor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(UrnaEleicoesEleitor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(UrnaEleicoesEleitor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UrnaEleicoesEleitor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new UrnaEleicoesEleitor().setVisible(true);
                
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnApaga;
    private javax.swing.JButton btnEntra;
    private javax.swing.JButton btnSair1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel ltitulo;
    private javax.swing.JTextField titulo1;
    // End of variables declaration//GEN-END:variables

    
}
