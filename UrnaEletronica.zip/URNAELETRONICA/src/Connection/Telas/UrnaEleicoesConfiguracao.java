package Connection.Telas;

import Connection.Mysql.ConnectionFactory;
import Connection.Mysql.login.envioDeVoto;
import Connection.Mysql.login.login;
import Connection.votos.Votos;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class UrnaEleicoesConfiguracao extends javax.swing.JFrame {     
    
    Votos voto = new Votos();
    envioDeVoto envio = new envioDeVoto();
    login login = new login();
    
    public UrnaEleicoesConfiguracao() {
        initComponents();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        usuario = new javax.swing.JLabel();
        tela1 = new javax.swing.JTextField();
        usuario1 = new javax.swing.JLabel();
        btnCorrigir = new javax.swing.JButton();
        btnConfirmar = new javax.swing.JButton();
        telasenha1 = new javax.swing.JPasswordField();
        btnApurar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(234, 242, 255));

        usuario.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        usuario.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        usuario.setText("Login:");
        usuario.setVerifyInputWhenFocusTarget(false);

        tela1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        tela1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        tela1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tela1FocusGained(evt);
            }
        });
        tela1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tela1ActionPerformed(evt);
            }
        });

        usuario1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        usuario1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        usuario1.setText("Senha:");
        usuario1.setVerifyInputWhenFocusTarget(false);

        btnCorrigir.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnCorrigir.setText("Apagar");
        btnCorrigir.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        btnCorrigir.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnCorrigir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCorrigirActionPerformed(evt);
            }
        });

        btnConfirmar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnConfirmar.setText("Entrar");
        btnConfirmar.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        btnConfirmar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnConfirmar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConfirmarActionPerformed(evt);
            }
        });

        telasenha1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                telasenha1ActionPerformed(evt);
            }
        });

        btnApurar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnApurar.setText("Apurar");
        btnApurar.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        btnApurar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnApurarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(usuario1, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(usuario, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(tela1, javax.swing.GroupLayout.PREFERRED_SIZE, 211, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(telasenha1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addComponent(btnCorrigir, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 22, Short.MAX_VALUE)
                .addComponent(btnApurar, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnConfirmar, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(41, 41, 41))
        );

        jPanel1Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {tela1, telasenha1});

        jPanel1Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnApurar, btnConfirmar, btnCorrigir});

        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(71, 71, 71)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tela1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(usuario))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(telasenha1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(usuario1))
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnConfirmar, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCorrigir, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnApurar))
                .addContainerGap(65, Short.MAX_VALUE))
        );

        jPanel1Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {tela1, telasenha1});

        jPanel1Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnApurar, btnConfirmar, btnCorrigir});

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(158, 158, 158)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(191, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(85, 85, 85)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(106, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnCorrigirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCorrigirActionPerformed
        tela1.setText("");
        telasenha1.setText("");
    }//GEN-LAST:event_btnCorrigirActionPerformed

    private void btnConfirmarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConfirmarActionPerformed
        entrar();
    }//GEN-LAST:event_btnConfirmarActionPerformed

    private void entrar(){
        if(validaCamposObrigatorios()){
            JOptionPane.showMessageDialog(null, "Preencha todos os campos !");
        }else{
            Connection con = ConnectionFactory.getConnection();
            String user = tela1.getText();
            String pass = telasenha1.getText();
            try{       
                Statement stm = con.createStatement();
                String sql = "select * from funcionario where login = '"+user+"' and senha = '"+pass+"'";
                ResultSet rs = stm.executeQuery(sql);      

                if(rs.next()){
                    int pk_func=rs.getInt(1);
                    voto.setChaveFuncionario(pk_func);
                    System.out.println("Primary Key do funcionario é: "+ pk_func);                
                    UrnaEleicoesEleitor eleitor = new UrnaEleicoesEleitor();
                    eleitor.funToEle(voto);
                    eleitor.setVisible(true);
                    con.close();
                    dispose();                
                }else{
                    JOptionPane.showMessageDialog(null, "Dados incorretos !","Erro",JOptionPane.ERROR_MESSAGE);
                    tela1.setText("");
                    telasenha1.setText("");
                }    

            }catch(SQLException e){
                JOptionPane.showMessageDialog(null, "Erro nos dados: " + e.toString());
            }
        } 
    }
    
    private void tela1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tela1ActionPerformed
       
    }//GEN-LAST:event_tela1ActionPerformed

    private void telasenha1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_telasenha1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_telasenha1ActionPerformed

    private void tela1FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tela1FocusGained
        // TODO add your handling code here:
    }//GEN-LAST:event_tela1FocusGained

    private void btnApurarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnApurarActionPerformed
        // TODO add your handling code here:
        if(validaCamposObrigatorios()){
            JOptionPane.showMessageDialog(null, "Preencha todos os campos !");
        }else{
            Connection con = ConnectionFactory.getConnection();
            String user = tela1.getText();
            String pass = telasenha1.getText();
            
            if(user.equals("admin") && pass.equals("eleicao2022")){
            
            }
            
            try{       
                Statement stm = con.createStatement();
                String sql = "select * from funcionario where login = '"+user+"' and senha = '"+pass+"'";
                ResultSet rs = stm.executeQuery(sql);      

                if(rs.next()){
                    int pk_admin=rs.getInt(1);
                    if(pk_admin == 1){               
                        UrnaEleicoesApuracao apura = new UrnaEleicoesApuracao();
                        apura.setVisible(true);
                        dispose();  
                    }else{
                        JOptionPane.showMessageDialog(null, "O usuario não tem permissão de acesso","Erro",JOptionPane.ERROR_MESSAGE);
                        tela1.setText("");
                        telasenha1.setText("");
                    }
                }else{
                    JOptionPane.showMessageDialog(null, "Dados incorretos !","Erro",JOptionPane.ERROR_MESSAGE);
                    tela1.setText("");
                    telasenha1.setText("");
                }    

            }catch(SQLException e){
                JOptionPane.showMessageDialog(null, "Erro nos dados: " + e.toString());
            }
        }
    }//GEN-LAST:event_btnApurarActionPerformed

    private boolean validaCamposObrigatorios(){
        return (tela1.getText().equals("") || telasenha1.getText().equals(""));
    }
    
    public static void main(String args[]) {        
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new UrnaEleicoesConfiguracao().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnApurar;
    private javax.swing.JButton btnConfirmar;
    private javax.swing.JButton btnCorrigir;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField tela1;
    private javax.swing.JPasswordField telasenha1;
    private javax.swing.JLabel usuario;
    private javax.swing.JLabel usuario1;
    // End of variables declaration//GEN-END:variables

    
}


