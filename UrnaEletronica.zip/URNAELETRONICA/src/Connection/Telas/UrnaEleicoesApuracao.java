/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Connection.Telas;

//import java.sql.*;
import Connection.Mysql.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;

/**
 *
 * @author bruno
 */
public class UrnaEleicoesApuracao extends javax.swing.JFrame {
    
    public void limpaTabela(){
        DefaultTableModel dm = (DefaultTableModel) tblApura.getModel();
        int rowCount = dm.getRowCount();
        for (int i = rowCount - 1; i >= 0; i--) {
          dm.removeRow(i);
        }
    }
    
    public UrnaEleicoesApuracao() {
        initComponents();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tblApura = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        btnPresidente = new javax.swing.JButton();
        btnGovernador = new javax.swing.JButton();
        btnSenador = new javax.swing.JButton();
        btnDepFed = new javax.swing.JButton();
        btnDepEst = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        tblApura.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "CANDIDATO", "NUMERO", "PARTIDO", "VOTOS"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Integer.class, java.lang.String.class, java.lang.Integer.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tblApura);
        if (tblApura.getColumnModel().getColumnCount() > 0) {
            tblApura.getColumnModel().getColumn(1).setMaxWidth(65);
            tblApura.getColumnModel().getColumn(3).setMaxWidth(50);
        }

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setText("APURAÇÃO DE VOTOS");

        btnPresidente.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        btnPresidente.setText("PRESIDENTE");
        btnPresidente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPresidenteActionPerformed(evt);
            }
        });

        btnGovernador.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        btnGovernador.setText("GOVERNADOR");
        btnGovernador.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGovernadorActionPerformed(evt);
            }
        });

        btnSenador.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        btnSenador.setText("SENADOR");
        btnSenador.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSenadorActionPerformed(evt);
            }
        });

        btnDepFed.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        btnDepFed.setText("DEP. FEDERAL");
        btnDepFed.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDepFedActionPerformed(evt);
            }
        });

        btnDepEst.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        btnDepEst.setText("DEP. ESTADUAL");
        btnDepEst.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDepEstActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(212, 212, 212)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(btnDepEst, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(btnDepFed, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnPresidente, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnGovernador, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnSenador, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 500, Short.MAX_VALUE)
                .addGap(28, 28, 28))
        );

        layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnDepEst, btnDepFed, btnGovernador, btnPresidente, btnSenador});

        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(55, 55, 55)
                .addComponent(jLabel1)
                .addGap(46, 46, 46)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnPresidente)
                        .addGap(18, 18, 18)
                        .addComponent(btnGovernador)
                        .addGap(18, 18, 18)
                        .addComponent(btnSenador)))
                .addGap(18, 18, 18)
                .addComponent(btnDepFed)
                .addGap(18, 18, 18)
                .addComponent(btnDepEst)
                .addContainerGap(169, Short.MAX_VALUE))
        );

        layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnDepEst, btnDepFed, btnGovernador, btnPresidente, btnSenador});

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnPresidenteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPresidenteActionPerformed
        limpaTabela();
        DefaultTableModel dm = (DefaultTableModel) tblApura.getModel();
        String sql = "select * from apurar_votos_presidentes"; 
        Connection con = ConnectionFactory.getConnection();        
        try{
            Statement stm = con.createStatement();            
            ResultSet rs = stm.executeQuery(sql);                    
            
            while(rs.next()){
               String candidato = rs.getString("CANDIDATO");
               String numero = String.valueOf(rs.getInt("NUMERO_ELEITORAL"));
               String partido = rs.getString("PARTIDO");
               String votos = String.valueOf(rs.getInt("VOTOS"));
               
               String tabela[] = {candidato,numero,partido,votos};
               
               dm.addRow(tabela);
            }                 
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, "Erro nos dados: " + e.toString());
        }
    }//GEN-LAST:event_btnPresidenteActionPerformed

    private void btnGovernadorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGovernadorActionPerformed
        limpaTabela();
        DefaultTableModel dm = (DefaultTableModel) tblApura.getModel();
        String sql = "select * from apurar_votos_governadores"; 
        Connection con = ConnectionFactory.getConnection();        
        try{
            Statement stm = con.createStatement();            
            ResultSet rs = stm.executeQuery(sql);                    
            
            while(rs.next()){
               String candidato = rs.getString("CANDIDATO");
               String numero = String.valueOf(rs.getInt("NUMERO_ELEITORAL"));
               String partido = rs.getString("PARTIDO");
               String votos = String.valueOf(rs.getInt("VOTOS"));
               
               String tabela[] = {candidato,numero,partido,votos};
               
               dm.addRow(tabela);
            }                 
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, "Erro nos dados: " + e.toString());
        }
    }//GEN-LAST:event_btnGovernadorActionPerformed

    private void btnSenadorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSenadorActionPerformed
        limpaTabela();
        DefaultTableModel dm = (DefaultTableModel) tblApura.getModel();
        String sql = "select * from apurar_votos_senadores"; 
        Connection con = ConnectionFactory.getConnection();        
        try{
            Statement stm = con.createStatement();            
            ResultSet rs = stm.executeQuery(sql);                    
            
            while(rs.next()){
               String candidato = rs.getString("CANDIDATO");
               String numero = String.valueOf(rs.getInt("NUMERO_ELEITORAL"));
               String partido = rs.getString("PARTIDO");
               String votos = String.valueOf(rs.getInt("VOTOS"));
               
               String tabela[] = {candidato,numero,partido,votos};
               
               dm.addRow(tabela);
            }                 
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, "Erro nos dados: " + e.toString());
        }
    }//GEN-LAST:event_btnSenadorActionPerformed

    private void btnDepFedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDepFedActionPerformed
        limpaTabela();
        DefaultTableModel dm = (DefaultTableModel) tblApura.getModel();
        String sql = "select * from apurar_votos_deputado_federal"; 
        Connection con = ConnectionFactory.getConnection();        
        try{
            Statement stm = con.createStatement();            
            ResultSet rs = stm.executeQuery(sql);                    
            
            while(rs.next()){
               String candidato = rs.getString("CANDIDATO");
               String numero = String.valueOf(rs.getInt("NUMERO_ELEITORAL"));
               String partido = rs.getString("PARTIDO");
               String votos = String.valueOf(rs.getInt("VOTOS"));
               
               String tabela[] = {candidato,numero,partido,votos};
               
               dm.addRow(tabela);
            }                 
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, "Erro nos dados: " + e.toString());
        }
    }//GEN-LAST:event_btnDepFedActionPerformed

    private void btnDepEstActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDepEstActionPerformed
        limpaTabela();
        DefaultTableModel dm = (DefaultTableModel) tblApura.getModel();
        String sql = "select * from apurar_votos_deputado_estadual"; 
        Connection con = ConnectionFactory.getConnection();        
        try{
            Statement stm = con.createStatement();            
            ResultSet rs = stm.executeQuery(sql);                    
            
            while(rs.next()){
               String candidato = rs.getString("CANDIDATO");
               String numero = String.valueOf(rs.getInt("NUMERO_ELEITORAL"));
               String partido = rs.getString("PARTIDO");
               String votos = String.valueOf(rs.getInt("VOTOS"));
               
               String tabela[] = {candidato,numero,partido,votos};
               
               dm.addRow(tabela);
            }                 
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, "Erro nos dados: " + e.toString());
        }
    }//GEN-LAST:event_btnDepEstActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(UrnaEleicoesApuracao.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(UrnaEleicoesApuracao.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(UrnaEleicoesApuracao.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UrnaEleicoesApuracao.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new UrnaEleicoesApuracao().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnDepEst;
    private javax.swing.JButton btnDepFed;
    private javax.swing.JButton btnGovernador;
    private javax.swing.JButton btnPresidente;
    private javax.swing.JButton btnSenador;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblApura;
    // End of variables declaration//GEN-END:variables
}
